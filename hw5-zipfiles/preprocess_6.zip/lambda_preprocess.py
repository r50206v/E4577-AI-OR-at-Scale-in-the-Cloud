import json
import preprocess
from preprocess import Preprocessor
path= "./glove_twitter_200d_clean.txt"
pre=Preprocessor(path)
def lambda_handler(event, context):
    tweet=event["tweet"]
    
    
    features=pre.pipeline(tweet)
    # TODO implement
    return {
        'features': features
    }
