import json 
import boto3
import preprocess
from preprocess import Preprocessor
path= "./glove_twitter_200d_clean.txt"
pre=Preprocessor(path)
sage_maker_client = boto3.client("runtime.sagemaker")

def lambda_handler(event, context):
  tweet= event["tweet"]

  features = pre.pipeline(tweet)
   
  model_payload = {
       'features_input' : features

   }
  response = sage_maker_client.invoke_endpoint(
             EndpointName="sagemaker-model",
             ContentType="application/json",
             Body=json.dumps(model_payload)) 
  result = json.loads(response["Body"].read().decode())

  print("Results: "+json.dumps(result, indent=2))
  return result
