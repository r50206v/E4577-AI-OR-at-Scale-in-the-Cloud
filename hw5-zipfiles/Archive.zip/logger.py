import json
import time
import boto3
import preprocess
from preprocess import Preprocessor
path = "./glove_twitter_200d_clean.txt"
pre = Preprocessor(path)
sage_maker_client = boto3.client("runtime.sagemaker")
s3 = boto3.client('s3')


def lambda_handler(event, context):
    request_time = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
    tweet = event["tweet"]

    pre_start = time.time()
    features = pre.pipeline(tweet)
    pre_end = time.time()

    model_payload = {
        'features_input': features
    }

    model_start = time.time()
    model_response = sage_maker_client.invoke_endpoint(
        EndpointName="sagemaker-model",
        ContentType="application/json",
        Body=json.dumps(model_payload)
    )
    model_end = time.time()

    result = json.loads(model_response["Body"].read().decode())
    response = {}
    if result["predictions"][0][0] >= 0.5:
        response["sentiment"] = "Positive"
    else:
        response["sentiment"] = "Negative"

    response['tweet'] = tweet
    response['probability'] = result["predictions"][0][0]
    response['preprocess_time'] = pre_end - pre_start
    response['model_time'] = model_end - model_start
    response['request_time'] = request_time

    store_info = s3.put_object(
        Bucket='as5646',
        Key='payload/request-%s.json' % request_time,
        Body=json.dumps(response, indent=2),
        ACL='public-read-write'
    )
    response['s3'] = store_info
    print("Results: "+json.dumps(response, indent=2))
    return response
